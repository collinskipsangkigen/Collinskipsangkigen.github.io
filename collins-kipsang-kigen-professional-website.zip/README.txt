COLLINS KIPSANG KIGEN — PROFESSIONAL AUTHOR WEBSITE

This version includes:
- Professional portrait
- Author-focused homepage
- About section
- Teaching portfolio
- Books section
- Whispers of Betrayal credited to Collins Kipsang Kigen & Dennis Koech
- The Shadows of Mystery credited to Collins Kipsang Kigen
- Professional journey timeline
- Email, WhatsApp and Facebook contact links
- Basic SEO metadata

Files:
- index.html
- collins-kipsang-kigen-professional.png

Upload both files to your web host while keeping them in the same folder.
